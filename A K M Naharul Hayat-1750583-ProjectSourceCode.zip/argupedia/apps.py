from django.apps import AppConfig


class ArgupediaConfig(AppConfig):
    name = 'argupedia'
